import json

with open("metrics.json") as f:
    data = json.load(f)

def f1(p, r):
    if p + r == 0:
        return 0.0
    return 2 * p * r / (p + r)

# overall
p = data["overall"]["precision"]
r = data["overall"]["recall"]
data["overall"]["f1"] = f1(p, r)

# per language
for lang, stats in data["by_language"].items():
    p = stats["precision"]
    r = stats["recall"]
    stats["f1"] = f1(p, r)

with open("metrics_with_f1.json", "w") as f:
    json.dump(data, f, indent=2)

print("Saved metrics_with_f1.json")

