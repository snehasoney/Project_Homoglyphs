#!/usr/bin/env python3
import json
from pathlib import Path

SRC = Path("rq4_compile_results/cpp/cpp.jsonl")
DST = Path("rq4_compile_results/cpp/cpp_oracle_normalized.jsonl")

def strip_out_prefix(p: str) -> str:
    p = (p or "").strip().replace("\\", "/")
    if p.startswith("out/"):
        return p[4:]
    return p

def with_out_prefix(p: str) -> str:
    p = strip_out_prefix(p)
    return "out/" + p if p else p

def pick_primary(gxx_val, clang_val):
    # prefer g++ value if present, else clang++
    return gxx_val if gxx_val is not None else clang_val

n = 0
with SRC.open("r", encoding="utf-8") as fin, DST.open("w", encoding="utf-8") as fout:
    for line in fin:
        line = line.strip()
        if not line:
            continue
        r = json.loads(line)

        # ---- path normalization ----
        raw_path = r.get("file_path") or r.get("source_file") or ""
        norm_path = strip_out_prefix(raw_path)

        r["language"] = "cpp"
        r["file_path"] = norm_path                  # canonical (NO out/)
        r["file_path_norm"] = norm_path             # helper join key
        r["file_path_out"] = with_out_prefix(norm_path)  # helper join key

        # ---- compile/run schema normalization ----
        compile_ok = pick_primary(r.get("gcc_compile_ok"), r.get("clang_compile_ok"))
        run_ok = pick_primary(r.get("gcc_run_ok"), r.get("clang_run_ok"))

        r["compile"] = {
            "ok": (bool(compile_ok) if compile_ok is not None else None)
        }
        r["run"] = {
            "attempted": bool(r.get("gcc_run_attempted") or r.get("clang_run_attempted")),
            "ok": (bool(run_ok) if run_ok is not None else None)
        }

        fout.write(json.dumps(r, ensure_ascii=False) + "\n")
        n += 1

print(f"Wrote {n} rows -> {DST}")

